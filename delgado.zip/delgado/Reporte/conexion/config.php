<?php

    define('DB_HOST','localhost');
    define('DB_NAME','hostperfecto_delgado');
    define('DB_USER','hostperfecto_senati');
    define('DB_PASSWORD','Senati123456.');
    define('DB_CHARSET','utf8');

?>