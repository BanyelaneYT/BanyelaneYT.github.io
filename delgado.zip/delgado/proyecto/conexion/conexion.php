<?php
    $db=mysqli_connect("localhost","hostperfecto","Senati123456.","hostperfecto_delgado");

    if(!$db){

            echo "Error de Conexion";

            exit;

        }

        echo "Conexion correcta";

?>    
