<?php

    $db=mysqli_connect("localhost","hostperfecto","Senati123456.","hostperfecto_delgado");

?>    
